const items = [
    {
        title: "Iusto est nihil aperiam sit voluptatem modi itaque?",
        content: (
            <p>
                Asperiores fugit occaecati. Iusto voluptatem facere rerum
                repudiandae fuga et aut. Assumenda qui rem dignissimos excepturi
                quasi possimus sed eos. Odit qui doloremque fuga quas.
            </p>
        ),
    },
    {
        title: "Numquam est nesciunt?",
        content: (
            <p>
                Asperiores fugit occaecati. Iusto voluptatem facere rerum
                repudiandae fuga et aut. Assumenda qui rem dignissimos excepturi
                quasi possimus sed eos. Odit qui doloremque fuga quas.
            </p>
        ),
    },
    {
        title: "Quisquam animi quis?",
        content: (
            <>
                <p>
                    Odio praesentium quam odit. Soluta molestiae tempora numquam
                    at veniam omnis. Molestiae nesciunt illo consectetur. Iusto
                    dolorem voluptatum voluptatum quia. Aliquid totam esse nobis
                    animi.
                </p>
                <p>
                    Laboriosam enim voluptas animi iure est. Dolorum dolores
                    tempore sunt qui totam recusandae ut nemo. Quibusdam id
                    tenetur omnis neque sed qui autem.
                </p>
            </>
        ),
    },
    {
        title: "Quaerat iusto debitis mollitia magnam?",
        content: (
            <>
                <p>
                    Odio praesentium quam odit. Soluta molestiae tempora numquam
                    at veniam omnis. Molestiae nesciunt illo consectetur. Iusto
                    dolorem voluptatum voluptatum quia. Aliquid totam esse nobis
                    animi.
                </p>
                <p>
                    Laboriosam enim voluptas animi iure est. Dolorum dolores
                    tempore sunt qui totam recusandae ut nemo. Quibusdam id
                    tenetur omnis neque sed qui autem.
                </p>
            </>
        ),
    },
    {
        title: "Sint sed officia aut dolorem quia et?",
        content: (
            <p>
                Asperiores fugit occaecati. Iusto voluptatem facere rerum
                repudiandae fuga et aut. Assumenda qui rem dignissimos excepturi
                quasi possimus sed eos. Odit qui doloremque fuga quas.
            </p>
        ),
    },
    {
        title: "Iste atque et sapiente?",
        content: (
            <>
                <p>
                    Odio praesentium quam odit. Soluta molestiae tempora numquam
                    at veniam omnis. Molestiae nesciunt illo consectetur. Iusto
                    dolorem voluptatum voluptatum quia. Aliquid totam esse nobis
                    animi.
                </p>
                <p>
                    Laboriosam enim voluptas animi iure est. Dolorum dolores
                    tempore sunt qui totam recusandae ut nemo. Quibusdam id
                    tenetur omnis neque sed qui autem.
                </p>
            </>
        ),
    },

    {
        title: "Quis beatae dolore dolore repellat nesciunt?",
        content: (
            <p>
                Asperiores fugit occaecati. Iusto voluptatem facere rerum
                repudiandae fuga et aut. Assumenda qui rem dignissimos excepturi
                quasi possimus sed eos. Odit qui doloremque fuga quas.
            </p>
        ),
    },

    {
        title: "Laborum eaque ut ad qui enim molestiae et magnam?",
        content: (
            <p>
                Asperiores fugit occaecati. Iusto voluptatem facere rerum
                repudiandae fuga et aut. Assumenda qui rem dignissimos excepturi
                quasi possimus sed eos. Odit qui doloremque fuga quas.
            </p>
        ),
    },
    {
        title: "How does staking work?",
        content: (
            <>
                <p>
                    Odio praesentium quam odit. Soluta molestiae tempora numquam
                    at veniam omnis. Molestiae nesciunt illo consectetur. Iusto
                    dolorem voluptatum voluptatum quia. Aliquid totam esse nobis
                    animi.
                </p>
                <p>
                    Laboriosam enim voluptas animi iure est. Dolorum dolores
                    tempore sunt qui totam recusandae ut nemo. Quibusdam id
                    tenetur omnis neque sed qui autem.
                </p>
            </>
        ),
    },
    {
        title: "Reprehenderit assumenda inventore est aperiam dolorum dolorum ducimus debitis eveniet?",
        content: (
            <>
                <p>
                    Odio praesentium quam odit. Soluta molestiae tempora numquam
                    at veniam omnis. Molestiae nesciunt illo consectetur. Iusto
                    dolorem voluptatum voluptatum quia. Aliquid totam esse nobis
                    animi.
                </p>
                <p>
                    Laboriosam enim voluptas animi iure est. Dolorum dolores
                    tempore sunt qui totam recusandae ut nemo. Quibusdam id
                    tenetur omnis neque sed qui autem.
                </p>
            </>
        ),
    },

    {
        title: "Ea rerum magnam aut?",
        content: (
            <p>
                Asperiores fugit occaecati. Iusto voluptatem facere rerum
                repudiandae fuga et aut. Assumenda qui rem dignissimos excepturi
                quasi possimus sed eos. Odit qui doloremque fuga quas.
            </p>
        ),
    },
    {
        title: "Perferendis voluptates repellat doloribus adipisci alias ex?",
        content: (
            <>
                <p>
                    Odio praesentium quam odit. Soluta molestiae tempora numquam
                    at veniam omnis. Molestiae nesciunt illo consectetur. Iusto
                    dolorem voluptatum voluptatum quia. Aliquid totam esse nobis
                    animi.
                </p>
                <p>
                    Laboriosam enim voluptas animi iure est. Dolorum dolores
                    tempore sunt qui totam recusandae ut nemo. Quibusdam id
                    tenetur omnis neque sed qui autem.
                </p>
            </>
        ),
    },
    {
        title: "Ea rerum magnam aut?",
        content: (
            <p>
                Asperiores fugit occaecati. Iusto voluptatem facere rerum
                repudiandae fuga et aut. Assumenda qui rem dignissimos excepturi
                quasi possimus sed eos. Odit qui doloremque fuga quas.
            </p>
        ),
    },
];

export { items };
