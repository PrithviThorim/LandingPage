const cards = [
    {
        url: "/character-details",
        title: "Astronauto #07892",
        label: "#07892",
        image: "/images/content/cards/image-1.png",
    },
    {
        url: "/character-details",
        title: "Astronauto #07892",
        label: "#07892",
        image: "/images/content/cards/image-2.png",
    },
    {
        url: "/character-details",
        title: "Astronauto #07892",
        label: "#07892",
        image: "/images/content/cards/image-3.png",
    },
    {
        url: "/character-details",
        title: "Astronauto #07892",
        label: "#07892",
        image: "/images/content/cards/image-4.png",
    },
    {
        url: "/character-details",
        title: "Astronauto #07892",
        label: "#07892",
        image: "/images/content/cards/image-5.png",
    },
    {
        url: "/character-details",
        title: "Astronauto #07892",
        label: "#07892",
        image: "/images/content/cards/image-1.png",
    },
    {
        url: "/character-details",
        title: "Astronauto #07892",
        label: "#07892",
        image: "/images/content/cards/image-2.png",
    },
    {
        url: "/character-details",
        title: "Astronauto #07892",
        label: "#07892",
        image: "/images/content/cards/image-3.png",
    },
    {
        url: "/character-details",
        title: "Astronauto #07892",
        label: "#07892",
        image: "/images/content/cards/image-4.png",
    },
    {
        url: "/character-details",
        title: "Astronauto #07892",
        label: "#07892",
        image: "/images/content/cards/image-5.png",
    },
];

export { cards };
